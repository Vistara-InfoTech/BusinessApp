package com.example.businessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Setting_Fragement extends Fragment {
    ImageView imageView;
    private int REQUEST_CODE=1;
    EditText old_password,new_password,confirm_password;
    Button save_changes,cancel_changes;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.setting,container,false);
        imageView=view.findViewById(R.id.change_photo);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"),REQUEST_CODE);
            }
        });
        old_password=view.findViewById(R.id.old_password);
        new_password =view.findViewById(R.id.new_password);
        confirm_password=view.findViewById(R.id.confirm_password);
        save_changes=view.findViewById(R.id.save_changes);
        save_changes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        cancel_changes=view.findViewById(R.id.cancel_changes);


        return view;
    }
}
