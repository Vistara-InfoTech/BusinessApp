package com.example.businessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Membership_Fragment extends Fragment {
    Button lite_membership,most_popular,handicked;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.membership_fragment,container,false);

        lite_membership=view.findViewById(R.id.lite_membership);
        lite_membership.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lite=new Intent(getContext(),Lite_Membership.class);
                startActivity(lite);
            }
        });

        most_popular=view.findViewById(R.id.most_popular);
        most_popular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent most_popular=new Intent(getContext(),Most_Popular.class);
                startActivity(most_popular);
            }
        });

        handicked=view.findViewById(R.id.handpicked);
        handicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent handpicked=new Intent(getContext(),HandPicked.class);
                startActivity(handpicked);
            }
        });
        return view;
    }
}
