package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Sign_Up_Registration extends AppCompatActivity {
    Spinner city;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up__registration);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        city=findViewById(R.id.city_spinnner);

        ArrayAdapter<String> CityAdapter = new ArrayAdapter<String>(Sign_Up_Registration.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.City));
        CityAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        city.setAdapter(CityAdapter);


        next=findViewById(R.id.next_button_1234);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Sign_Up_Registration.this,Sign_Up_Registration_Second.class);
                startActivity(intent);
            }
        });


    }
}
