package com.example.businessapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Banner_Adapter extends RecyclerView.Adapter<Banner_Adapter.MY_VIEW_HOLDER> {


    private String[] data;

    public Banner_Adapter(String[] data) {
        this.data = data;

    }


    @NonNull
    @Override
    public MY_VIEW_HOLDER onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.banner_model_first, parent, false);
        return new  Banner_Adapter.MY_VIEW_HOLDER(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MY_VIEW_HOLDER holder, int position) {

    }


    @Override
    public int getItemCount() {
        return data.length;
    }

    public class MY_VIEW_HOLDER extends RecyclerView.ViewHolder {
        TextView request;
        ImageView icon;
        Button button;

        public MY_VIEW_HOLDER(@NonNull View itemView) {
            super(itemView);


            request = itemView.findViewById(R.id.memeber_like_to_text_view);
            icon = itemView.findViewById(R.id.work_icon_banner);
            button =itemView.findViewById(R.id.add_work_detail_button);
        }
    }
}
