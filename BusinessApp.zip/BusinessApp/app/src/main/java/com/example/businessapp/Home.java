package com.example.businessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout1;
    NavigationView navigationView;
    ActionBarDrawerToggle actionBarDrawerToggle2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        drawerLayout1 = findViewById(R.id.vender_drawer_layout);
        Toolbar toolbar1 = findViewById(R.id.drawer_toolbar_nevigation_login_vender_login);
        setSupportActionBar(toolbar1);
        getSupportActionBar().setTitle("User Name");
        navigationView=(NavigationView)findViewById(R.id.drawer_navigation_view_vender_third) ;

        ActionBarDrawerToggle actionBarDrawerToggle2 = new ActionBarDrawerToggle(this, drawerLayout1, toolbar1,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorRed)));


        drawerLayout1.addDrawerListener(actionBarDrawerToggle2);
        actionBarDrawerToggle2.syncState();

        toolbar1.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout1.openDrawer(GravityCompat.START);
                drawerLayout1.setOnClickListener(this);


            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                Fragment fragment = null;

               /* switch (menuItem.getItemId()) {
                    case R.id.home_drawer_vender3_sign_up_form:
                        fragment=new Home_Deshboard1();
                        break;

                    case R.id.information_drawer:
                        fragment=new Information_Fragment();
                        break;

                    case R.id.projects_drawer:
                        fragment=new Project_Fragment();
                        break;

                    case R.id.Membership_plan_drawer2:
                        fragment=new Membership_Fragment();
                        break;

                    case R.id.reviees_drawer:
                        fragment=new Review_Fragment();
                        break;
                }

*/
                if (id == R.id.home_drawer_vender3_sign_up_form) {
                    fragment = new Home_Deshboard1();


                } else if (id == R.id.information_drawer) {
                    fragment=new Information_Fragment();

                } else if (id == R.id.projects_drawer) {
                    fragment=new Project_Fragment();


                } else if (id == R.id.Membership_plan_drawer2) {
                    fragment=new Membership_Fragment();


                } else if (id == R.id.reviees_drawer) {
                    fragment=new Review_Fragment();


                }
                else if (id == R.id.setting_drawer) {
                    fragment=new Setting_Fragement ();


                }
                else if (id == R.id.reply_drawer) {
                    fragment=new Reply_Message ();


                }
                else if (id == R.id.inbox_drawer) {
                    fragment=new Inbox_First();


                }


                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container_login_vender3, fragment).addToBackStack(null).commit();



                drawerLayout1.closeDrawer(GravityCompat.START);

                return true;
            }
        });


        loadfragement(new Home_Deshboard1());



    }

    @Override
    public void onBackPressed() {
        if (drawerLayout1.isDrawerOpen(GravityCompat.START)) {
            drawerLayout1.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    private boolean loadfragement(Fragment fragment) {


        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container_login_vender3, fragment)
                .commit();
        return true;

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;

        switch (menuItem.getItemId()) {

            case R.id.information_drawer:
                break;

            case R.id.projects_drawer:
                break;

            case R.id.Membership_plan_drawer2:
                break;

            case R.id.reviees_drawer:
                break;
        }


        return false;
    }
}
