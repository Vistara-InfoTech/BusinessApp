package com.example.businessapp;

import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Inbox_Model {

    int  photo;
    String name,online_profile_write_rewiews,inbox_content,read_more_inbox,reply_text;

    public Inbox_Model(int photo, String name, String online_profile_write_rewiews, String inbox_content, String read_more_inbox, String reply_text) {
        this.photo = photo;
        this.name = name;
        this.online_profile_write_rewiews = online_profile_write_rewiews;
        this.inbox_content = inbox_content;
        this.read_more_inbox = read_more_inbox;
        this.reply_text = reply_text;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOnline_profile_write_rewiews() {
        return online_profile_write_rewiews;
    }

    public void setOnline_profile_write_rewiews(String online_profile_write_rewiews) {
        this.online_profile_write_rewiews = online_profile_write_rewiews;
    }

    public String getInbox_content() {
        return inbox_content;
    }

    public void setInbox_content(String inbox_content) {
        this.inbox_content = inbox_content;
    }

    public String getRead_more_inbox() {
        return read_more_inbox;
    }

    public void setRead_more_inbox(String read_more_inbox) {
        this.read_more_inbox = read_more_inbox;
    }

    public String getReply_text() {
        return reply_text;
    }

    public void setReply_text(String reply_text) {
        this.reply_text = reply_text;
    }
}
