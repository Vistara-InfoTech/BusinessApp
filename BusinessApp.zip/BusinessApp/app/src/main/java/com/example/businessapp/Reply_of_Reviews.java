
package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Reply_of_Reviews extends AppCompatActivity {

    ImageView imageView;
    private final int PICK_IMAGE=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_of__reviews);
        imageView=findViewById(R.id.gallery_open);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallry=new Intent();
                gallry.setType("image/*");
                gallry.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallry,"Select Image"),PICK_IMAGE);
            }
        });
    }
}

