package com.example.businessapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Inbox_Adapter extends RecyclerView.Adapter<Inbox_Adapter.My_View_Holder>  {

    Inbox_Adapter inbox_adapter;

    public Inbox_Adapter(Inbox_Adapter inbox_adapter) {
        this.inbox_adapter = inbox_adapter;
    }

    Context context;
    List<Inbox_Model> inbox_model;

    public Inbox_Adapter(Context context, List<Inbox_Model> inbox_model) {
        this.context = context;
        this.inbox_model = inbox_model;
    }

    @NonNull
    @Override
    public My_View_Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.inbox_model,parent,false);
        return new  Inbox_Adapter.My_View_Holder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull My_View_Holder holder, int position) {

        holder.name.setText(inbox_model.get(position).getName());
        holder.online_profile_write_rewiews.setText(inbox_model.get(position).getOnline_profile_write_rewiews());
        holder.inbox_content.setText(inbox_model.get(position).getOnline_profile_write_rewiews());
        holder.read_more_inbox.setText(inbox_model.get(position).getRead_more_inbox());
        holder.reply_text.setText(inbox_model.get(position).getReply_text());
    }


    @Override
    public int getItemCount() {
        return inbox_model.size();
    }




    public class My_View_Holder extends RecyclerView.ViewHolder {
        ImageView photo;
        TextView name,online_profile_write_rewiews,inbox_content,read_more_inbox,reply_text;
        public My_View_Holder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();


           photo=itemView.findViewById(R.id.inbox_profile);
           name=itemView.findViewById(R.id.name_profile_inbox);
           online_profile_write_rewiews=itemView.findViewById(R.id.online_profile_inbox);
           inbox_content=itemView.findViewById(R.id.inbox_content);
           read_more_inbox=itemView.findViewById(R.id.read_more_inbox);
           reply_text=itemView.findViewById(R.id.reply_text);
           itemView.setClickable(true);


        }
    }
/*
    @Override
    public void onClick(View v) {

        final Intent intent;
        switch (getAdapterPostion()){
            case 0:
                intent =  new Intent(context, FirstActivity.class);
                break;

            case 1:
                intent =  new Intent(context, SecondActivity.class);
                break;

            default:
                intent =  new Intent(context, DefaultActivity.class);
                break;
        }
        context.startActivity(intent);

    }

*/

}
