package com.example.businessapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

public class Home_Deshboard1 extends Fragment {
    RecyclerView recyclerView,recyclerView2,recyclerView3;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.home_deshboard,container,false);

        recyclerView=view.findViewById(R.id.home_vender_sign_up);
        SnapHelper snapHelper4 = new LinearSnapHelper();
        snapHelper4.attachToRecyclerView(recyclerView);

        LinearLayoutManager layoutManager4 = new LinearLayoutManager(this.getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager4);
        String[] profile_name4 = {"Meera Gupta", "Vedika", "Avantika", "Sonam Verma", "Sonali Rai", "Shubhangi Nimje", "Madhulika Yadav", "Aarati Verma", "Shivani Raikhere", "Princy jain"};
        recyclerView.setAdapter(new Banner_Adapter(profile_name4));

        recyclerView2=view.findViewById(R.id.my_uploads_recycleview);
        SnapHelper snapHelper = new LinearSnapHelper();
        snapHelper.attachToRecyclerView(recyclerView2);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this.getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView2.setLayoutManager(layoutManager);
        String[] profile_name = {"Meera Gupta", "Vedika", "Avantika", "Sonam Verma", "Sonali Rai", "Shubhangi Nimje", "Madhulika Yadav", "Aarati Verma", "Shivani Raikhere", "Princy jain"};
        recyclerView2.setAdapter(new My_Uploads(profile_name));

        recyclerView3=view.findViewById(R.id.myreviews_recycleview);
        SnapHelper snapHelper3 = new LinearSnapHelper();
        snapHelper3.attachToRecyclerView(recyclerView3);
        LinearLayoutManager layoutManager3 = new LinearLayoutManager(this.getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView3.setLayoutManager(layoutManager3);
        String[] profile_name3 = {"Meera Gupta", "Vedika", "Avantika", "Sonam Verma", "Sonali Rai", "Shubhangi Nimje", "Madhulika Yadav", "Aarati Verma", "Shivani Raikhere", "Princy jain"};
        recyclerView3.setAdapter(new Reviews_Adater(profile_name3));



        return view;
    }
}
