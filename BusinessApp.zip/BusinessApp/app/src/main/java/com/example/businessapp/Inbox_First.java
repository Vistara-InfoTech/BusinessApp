package com.example.businessapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import java.util.ArrayList;
import java.util.List;

public class Inbox_First extends Fragment {
//   private RecyclerView recyclerView;
//   private List<Inbox_Model> list_item;
//   private Inbox_Adapter inbox_adapter;
//   private LinearLayoutManager linearLayoutManager;

 //   public Inbox_First( List<Inbox_Model> list_item, Inbox_Adapter inbox_adapter) {
     //   this.list_item = list_item;
     //   this.inbox_adapter = inbox_adapter;
//    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.inbox_first,container,false);
     //   recyclerView=view.findViewById(R.id.inbox_recycleview);
      //  SnapHelper snapHelper3 = new LinearSnapHelper();
      //  snapHelper3.attachToRecyclerView(recyclerView);
     //   list_item =new ArrayList<>();
      //  inbox_adapter=new Inbox_Adapter(getActivity(),list_item);
      //  linearLayoutManager=new LinearLayoutManager(getActivity());
     //   recyclerView.setAdapter(inbox_adapter);
    //    recyclerView.setLayoutManager(linearLayoutManager);
//



        return view;
    }





}
