package com.example.businessapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Reviews_Adater extends RecyclerView.Adapter<Reviews_Adater.My_view_Holder> {

    private String[] data;

    public Reviews_Adater(String[] data) {
        this.data = data;

    }


    @NonNull
    @Override
    public My_view_Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.reviews_model, parent, false);
        return new Reviews_Adater.My_view_Holder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull My_view_Holder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return data.length;
    }


    public class My_view_Holder extends RecyclerView.ViewHolder {

        ImageView profile_image;
        TextView name,online,review_content,read_more,remaining_content;
        RelativeLayout relativeLayout;
        public My_view_Holder(@NonNull View itemView) {
            super(itemView);
            profile_image=itemView.findViewById(R.id.write_review_profile);
            name=itemView.findViewById(R.id.name_profile_write_rewiews);
            online=itemView.findViewById(R.id.online_profile_write_rewiews);
            review_content=itemView.findViewById(R.id.review_content);
            read_more=itemView.findViewById(R.id.read_more);
            remaining_content=itemView.findViewById(R.id.remaining_content);
            relativeLayout=itemView.findViewById(R.id.relative_layout_rewiew_content);
        }
    }
}

