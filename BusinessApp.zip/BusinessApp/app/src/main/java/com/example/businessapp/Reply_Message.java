package com.example.businessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Reply_Message extends Fragment {
    ImageView imageView;
    private final int PICK_IMAGE=1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.reply_message,container,false);
        imageView=view.findViewById(R.id.gallery_open1);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallry=new Intent();
                gallry.setType("image/*");
                gallry.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallry,"Select Image"),PICK_IMAGE);
            }
        });
        return view;
    }
}
