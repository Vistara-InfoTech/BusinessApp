package com.example.businessapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

public class Review_Fragment extends Fragment {

 RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.review_fragment,container,false);
        recyclerView=view.findViewById(R.id.review_recycleview);
        SnapHelper snapHelper3 = new LinearSnapHelper();
        snapHelper3.attachToRecyclerView(recyclerView);
        LinearLayoutManager layoutManager3 = new LinearLayoutManager(this.getActivity());
        recyclerView.setLayoutManager(layoutManager3);
        String[] profile_name3 = {"Meera Gupta", "Vedika", "Avantika", "Sonam Verma", "Sonali Rai", "Shubhangi Nimje", "Madhulika Yadav", "Aarati Verma", "Shivani Raikhere", "Princy jain"};
        recyclerView.setAdapter(new Reviews_Adater(profile_name3));

        return view;
    }
}


