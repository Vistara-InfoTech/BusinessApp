package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Forget_Password_First extends AppCompatActivity {
    Button resetpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget__password__first);


        resetpassword = findViewById( R.id.resetpassword );


            resetpassword.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity( new Intent( getApplicationContext(), Forget_Password_Second.class ) );
                }
            } );
        }

        }


