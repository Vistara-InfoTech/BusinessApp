package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Sign_Up_Registration_Second extends AppCompatActivity {
    Spinner Vender_Category;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up__registration__second);

        Vender_Category=findViewById(R.id.vender_sign_up);
        save=findViewById(R.id.save_infor);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        ArrayAdapter<String> VenderAdapter = new ArrayAdapter<String>(Sign_Up_Registration_Second.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Vender_SignUp));
        VenderAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        Vender_Category.setAdapter(VenderAdapter);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
            }
        });


    }
}
