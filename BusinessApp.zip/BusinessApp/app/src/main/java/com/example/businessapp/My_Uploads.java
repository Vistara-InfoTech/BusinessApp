package com.example.businessapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class My_Uploads extends RecyclerView.Adapter <My_Uploads.View_Holder>{
    private String[] data;

    public My_Uploads(String[] data) {
        this.data = data;
    }
    @NonNull
    @Override
    public View_Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.my_uploads_model,parent,false);
        return new  My_Uploads.View_Holder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull View_Holder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class View_Holder extends RecyclerView.ViewHolder {
        ImageView imageView,imageView1;
        public View_Holder(@NonNull View itemView) {
            super(itemView);

            imageView=itemView.findViewById(R.id.album1);
          //  imageView1= itemView.findViewById(R.id.album2);
        }
    }
}
