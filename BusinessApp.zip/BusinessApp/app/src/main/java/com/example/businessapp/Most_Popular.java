package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Most_Popular extends AppCompatActivity {
    Button most_popular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_most__popular);
        most_popular=findViewById(R.id.most_popular_membership_requested);
        most_popular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                most_popular.setText("Requested");
            }
        });
    }
}
